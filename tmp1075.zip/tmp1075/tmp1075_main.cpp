#include "tmp1075.hpp"
#include <px4_platform_common/module.h>

extern "C" __EXPORT int tmp1075_main(int argc, char *argv[])
{
    return I2CSPIDriverBase::main<TMP1075>(argc, argv);
}
