#include "tmp1075.hpp"

extern "C" __EXPORT int tmp1075_i2c3_main(int argc, char *argv[])
{
    I2CSPIDriverConfig config{};
    config.bus_type = I2C_BUS_ALL;  // PX4 tự xác định bus
    config.bus = 3;                 // ép dùng I2C3
    config.address = 0x4F;          // địa chỉ TMP1075
    config.priority = px4::device_bus_to_wq(config.bus_type, config.bus);

    TMP1075 *driver = new TMP1075(config);
    if (!driver) {
        PX4_ERR("Driver allocation failed");
        return PX4_ERROR;
    }

    return I2CSPIDriverBase::main<TMP1075>(argc, argv);
}
