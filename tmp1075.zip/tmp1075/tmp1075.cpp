#include "tmp1075.hpp"
#include <px4_platform_common/log.h>
#include <lib/perf/perf_counter.h>

#define TMP1075_TEMP_REG 0x00

TMP1075::TMP1075(const I2CSPIDriverConfig &config)
: I2C(DRV_TEMPERATURE_DEVTYPE_TMP1075, config),
  I2CSPIDriver(MODULE_NAME, px4::device_bus_to_wq(config.bus_type, config.bus))
{
    _sample_perf = perf_alloc(PC_ELAPSED, MODULE_NAME ": sample");
}

TMP1075::~TMP1075()
{
    perf_free(_sample_perf);
}

int TMP1075::read_temperature(float &temp_c)
{
    uint8_t buf[2]{};

    if (transfer(&TMP1075_TEMP_REG, 1, buf, 2) != PX4_OK) {
        PX4_ERR("I2C read failed");
        return PX4_ERROR;
    }

    int16_t raw_temp = (buf[0] << 8) | buf[1];
    temp_c = raw_temp * 0.0625f; // TMP1075: 0.0625°C per LSB
    return PX4_OK;
}

void TMP1075::RunImpl()
{
    perf_begin(_sample_perf);

    float temp = 0.f;
    if (read_temperature(temp) == PX4_OK) {
        sensor_temperature_s msg{};
        msg.timestamp = hrt_absolute_time();
        msg.temperature = temp;
        msg.device_id = get_device_id();
        _sensor_pub.publish(msg);
    }

    perf_end(_sample_perf);
    ScheduleDelayed(1_s);
}

int TMP1075::init()
{
    if (I2C::init() != PX4_OK) {
        PX4_ERR("I2C init failed");
        return PX4_ERROR;
    }

    ScheduleNow();
    return PX4_OK;
}

I2CSPIDriverBase *TMP1075::instantiate(const I2CSPIDriverConfig &config, int /*runtime_instance*/)
{
    return new TMP1075(config);
}

void TMP1075::print_usage()
{
    PRINT_MODULE_USAGE_NAME("tmp1075", "driver");
    PRINT_MODULE_USAGE_COMMAND("start");
    PRINT_MODULE_USAGE_PARAM_INT('b', 3, 1, 3, "I2C bus number", true);
    PRINT_MODULE_USAGE_PARAM_INT('a', 0x4F, 0x48, 0x4F, "I2C address", true);
}
