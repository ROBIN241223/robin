#pragma once
#include <lib/drivers/device/i2c.h>
#include <px4_platform_common/i2c_spi_buses.h>
#include <px4_platform_common/board_common.h> // This include is correct, no change needed.
#include <uORB/Publication.hpp>
#include <uORB/topics/sensor_temperature.h>

class TMP1075 : public device::I2C, public I2CSPIDriver<TMP1075>
{
public:
    TMP1075(const I2CSPIDriverConfig &config);
    ~TMP1075() override;

    static I2CSPIDriverBase *instantiate(const I2CSPIDriverConfig &config, int runtime_instance);
    static void print_usage();
    void RunImpl() override;
    int init() override;

private:
    int read_temperature(float &temp_c);

    uORB::Publication<sensor_temperature_s> _sensor_pub{ORB_ID(sensor_temperature)};
    perf_counter_t _sample_perf{nullptr};
};
