#include "hdc3020.hpp"
#include <px4_platform_common/module.h>

extern "C" __EXPORT int hdc3020_main(int argc, char *argv[])
{
    return I2CSPIDriverBase::main<HDC3020>(argc, argv);
}
