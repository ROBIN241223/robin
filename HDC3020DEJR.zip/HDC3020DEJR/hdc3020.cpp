#include "hdc3020.hpp"
#include <px4_platform_common/log.h>
#include <lib/perf/perf_counter.h>
#include <math.h>

#define HDC3020_TEMP_REG      0x00
#define HDC3020_HUM_REG       0x01
#define HDC3020_CONFIG_REG    0x02
#define HDC3020_MEASURE_TEMP  0x1000  // command temp+humidity

HDC3020::HDC3020(const I2CSPIDriverConfig &config)
: I2C(DRV_HYGROMETER_DEVTYPE_HDC3020, config),
  I2CSPIDriver(MODULE_NAME, px4::device_bus_to_wq(config.bus_type, config.bus))
{
    _sample_perf = perf_alloc(PC_ELAPSED, MODULE_NAME ": sample");
}

HDC3020::~HDC3020()
{
    perf_free(_sample_perf);
}

int HDC3020::read_temperature_humidity(float &temp_c, float &humidity)
{
    uint8_t buf[4]{};
    uint16_t cmd = HDC3020_MEASURE_TEMP;
    uint8_t cmd_buf[2] = { (uint8_t)(cmd >> 8), (uint8_t)(cmd & 0xFF) };

    if (transfer(cmd_buf, 2, nullptr, 0) != PX4_OK) {
        PX4_ERR("I2C write failed");
        return PX4_ERROR;
    }

    px4_usleep(7000);

    if (transfer(nullptr, 0, buf, sizeof(buf)) != PX4_OK) {
        PX4_ERR("I2C read failed");
        return PX4_ERROR;
    }

    uint16_t raw_temp = (buf[0] << 8) | buf[1];
    uint16_t raw_hum  = (buf[2] << 8) | buf[3];

    temp_c = (raw_temp / 65536.0f) * 165.0f - 40.0f;
    humidity = (raw_hum / 65536.0f) * 100.0f;

    return PX4_OK;
}

void HDC3020::RunImpl()
{
    perf_begin(_sample_perf);

    float temp = 0.f, hum = 0.f;

    if (read_temperature_humidity(temp, hum) == PX4_OK) {
        sensor_hygrometer_s msg{};
        msg.timestamp = hrt_absolute_time();
        msg.temperature = temp;
        msg.humidity = hum;
        msg.device_id = get_device_id();
        _sensor_pub.publish(msg);
    }

    perf_end(_sample_perf);
    ScheduleDelayed(1_s);
}

int HDC3020::init()
{
    if (I2C::init() != PX4_OK) {
        PX4_ERR("I2C init failed");
        return PX4_ERROR;
    }

    ScheduleNow();
    return PX4_OK;
}

I2CSPIDriverBase *HDC3020::instantiate(const I2CSPIDriverConfig &config, int /*runtime_instance*/)
{
    return new HDC3020(config);
}

void HDC3020::print_usage()
{
    PRINT_MODULE_USAGE_NAME("hdc3020", "driver");
    PRINT_MODULE_USAGE_COMMAND("start");
    PRINT_MODULE_USAGE_PARAM_INT('b', 3, 1, 3, "I2C bus number", true);
    PRINT_MODULE_USAGE_PARAM_INT('a', 0x44, 0x40, 0x4F, "I2C address", true);
}
