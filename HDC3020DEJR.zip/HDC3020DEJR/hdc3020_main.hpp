/****************************************************************************
 *   HDC3020DEJR (TI) – RH & Temperature Sensor (I2C)
 *   PX4 module entry point (CLI / shell)
 ****************************************************************************/

#pragma once

#include "hdc3020.hpp"
#include <px4_platform_common/module.h>
#include <px4_platform_common/getopt.h>

extern "C" __EXPORT int hdc3020_main(int argc, char *argv[]);

static void usage()
{
    PRINT_MODULE_DESCRIPTION(
        R"DESCR_STR(
### Description
Driver cho cảm biến HDC3020 (TI) – nhiệt độ & độ ẩm, giao tiếp I2C.

- Publish uORB: `sensor_hygrometer`
- Parameters: `HDC30X_RATE` (Hz), `HDC30X_ADDR` (-1=auto), `HDC30X_HEAT`
)DESCR_STR");

    PRINT_MODULE_USAGE_NAME("hdc3020", "drivers");
    PRINT_MODULE_USAGE_COMMAND("start");
    PRINT_MODULE_USAGE_PARAM_INT('b', 1, 1, 10, "I2C bus", true);
    PRINT_MODULE_USAGE_PARAM_INT('a', -1, -1, 0x7f, "I2C address (-1=auto)", true);
    PRINT_MODULE_USAGE_PARAM_INT('f', 400000, 100000, 1000000, "I2C frequency", true);
    PRINT_MODULE_USAGE_COMMAND("stop");
    PRINT_MODULE_USAGE_COMMAND("status");
}

int hdc3020_main(int argc, char *argv[])
{
    if (argc < 2) {
        usage();
        return -EINVAL;
    }

    const char *verb = argv[1];
    int ch;
    int optind = 1;
    int i2c_bus = 1;
    int i2c_addr = -1;
    int bus_freq = 400000;

    static HDC3020 *inst = nullptr;

    if (!strcmp(verb, "start")) {

        while ((ch = px4_getopt(argc, argv, "b:a:f:", &optind, nullptr)) != EOF) {
            switch (ch) {
            case 'b': i2c_bus = atoi(px4_optarg); break;
            case 'a': i2c_addr = strtol(px4_optarg, nullptr, 0); break;
            case 'f': bus_freq = atoi(px4_optarg); break;
            default: usage(); return -EINVAL;
            }
        }

        if (inst) {
            PX4_WARN("already started");
            return PX4_OK;
        }

        inst = new HDC3020(i2c_bus, bus_freq, i2c_addr);

        if (!inst) {
            PX4_ERR("alloc failed");
            return -ENOMEM;
        }

        if (inst->init() != PX4_OK) {
            delete inst;
            inst = nullptr;
            return -EIO;
        }

        return inst->start();
    }

    if (!strcmp(verb, "stop")) {
        if (inst) {
            inst->stop();
            delete inst;
            inst = nullptr;
            return PX4_OK;
        }
        PX4_WARN("not running");
        return PX4_OK;
    }

    if (!strcmp(verb, "status")) {
        if (inst) {
            inst->print_status();
            return PX4_OK;
        }
        PX4_WARN("not running");
        return PX4_OK;
    }

    usage();
    return -EINVAL;
}
