#pragma once
#include <px4_platform_common/i2c_spi_buses.h>
#include <lib/drivers/device/i2c.h>
#include <uORB/Publication.hpp>
#include <uORB/topics/sensor_hygrometer.h>

class HDC3020 : public device::I2C, public I2CSPIDriver<HDC3020>
{
public:
    HDC3020(const I2CSPIDriverConfig &config);
    ~HDC3020() override;

    static I2CSPIDriverBase *instantiate(const I2CSPIDriverConfig &config, int runtime_instance);
    static void print_usage();
    void RunImpl() override;
    int init() override;

private:
    int read_temperature_humidity(float &temp_c, float &humidity);

    uORB::Publication<sensor_hygrometer_s> _sensor_pub{ORB_ID(sensor_hygrometer)};
    perf_counter_t _sample_perf{nullptr};
};
