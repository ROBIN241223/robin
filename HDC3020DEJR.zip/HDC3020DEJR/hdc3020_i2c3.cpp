#include "hdc3020.hpp"

extern "C" __EXPORT int hdc3020_i2c3_main(int argc, char *argv[])
{
    I2CSPIDriverConfig config{};
    config.bus_type = I2C_BUS_ALL;
    config.bus = 3;        // ép dùng I2C3
    config.address = 0x44; // địa chỉ HDC3020
    config.priority = px4::device_bus_to_wq(config.bus_type, config.bus);

    HDC3020 *driver = new HDC3020(config);
    if (!driver) {
        PX4_ERR("Driver allocation failed");
        return PX4_ERROR;
    }

    return I2CSPIDriverBase::main<HDC3020>(argc, argv);
}
